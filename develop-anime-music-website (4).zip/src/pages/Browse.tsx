import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { getFreshTracks, getRandomTracks, getSeasonAnime, getSeasonTracks, getYearTracks } from "@/api/animethemes";
import { randomExtras, searchMix, searchStudio, searchCommunity } from "@/api/extraSources";
import { warmMeta } from "@/api/meta";
import { GENRES, filterMature, useGenreFilter } from "@/core/catalog";
import { useGeneralStore } from "@/store/general";
import { useSettings } from "@/store/settings";
import type { AnimeSummary, Season, Track } from "@/types";
import { useAsync } from "@/lib/hooks";
import { SEASONS, SEASON_RU, dayKey, haptic, lastDays, relativeDay, uniqueBy } from "@/lib/utils";
import { usePlayerActions } from "@/store/player";
import { useUIActions } from "@/store/ui";
import { cn } from "@/utils/cn";
import { Icon } from "@/components/Icon";
import { TopBar } from "@/components/Nav";
import { AnimeCard, TrackCard, TrackRow } from "@/components/cards";
import { Button, Chip, EmptyState, ErrorState, HScroll, IconButton, Segmented, Skeleton, Spinner, TrackRowSkeleton } from "@/components/ui";

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: CURRENT_YEAR + 1 - 1990 + 1 }, (_, i) => CURRENT_YEAR + 1 - i);
type Feed = "years" | "fresh" | "genres" | "extra";



export default function BrowsePage() {
  const [params, setParams] = useSearchParams();
  const feed = (params.get("feed") as Feed | null) ?? "years";
  const setFeed = (v: Feed) => {
    const n = new URLSearchParams(params);
    if (v === "years") n.delete("feed");
    else n.set("feed", v);
    setParams(n, { replace: true });
    haptic(6);
    window.scrollTo({ top: 0 });
  };

  return (
    <div className="animate-fade-in pb-8">
      <TopBar large title="Обзор" />
      <div className="mx-auto max-w-6xl">
        <div className="px-4 pb-1 pt-2 md:px-6">
          <Segmented
            value={feed}
            onChange={setFeed}
            items={[
              { value: "years", label: "Годы" },
              { value: "fresh", label: "Новинки" },
              { value: "genres", label: "Жанры" },
              { value: "extra", label: "Ещё" },
            ]}
          />
        </div>
        {feed === "years" && <YearsFeed />}
        {feed === "fresh" && <FreshFeed />}
        {feed === "genres" && <GenresFeed />}
        {feed === "extra" && <ExtraFeed />}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* ГОДЫ: 2026 → песня, песня, песня                                    */
/* ------------------------------------------------------------------ */
function YearsFeed() {
  const navigate = useNavigate();
  const player = usePlayerActions();
  const { mature } = useGeneralStore();
  const [year, setYear] = useState<number>(CURRENT_YEAR);

  const r = useAsync<Track[]>((s) => getYearTracks(year, 90, { signal: s, priority: "high" }), [year]);
  const animeR = useAsync((s) => getSeasonAnime(year, null, 1, { signal: s }), [year]);
  const tracks = useMemo(() => filterMature(r.data ?? [], mature), [r.data, mature]);
  const counts = useMemo(() => ({ OP: tracks.filter((t) => t.type === "OP").length, ED: tracks.filter((t) => t.type === "ED").length }), [tracks]);

  useEffect(() => warmMeta(tracks.map((t) => t.anime.malId)), [tracks]);

  return (
    <div className="pt-3">
      {/* Лента годов: 2026 сверху */}
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-2 md:px-6">
        <button
          type="button"
          onClick={() => { setYear(CURRENT_YEAR + 1); haptic(6); }}
          className={cn("flex h-11 shrink-0 flex-col items-center justify-center rounded-[12px] px-4", year === CURRENT_YEAR + 1 ? "bg-white text-black" : "bg-surface-2 text-on-surface-variant")}
        >
          <span className="text-[14px] font-bold">{CURRENT_YEAR + 1}</span>
          <span className="text-[10px] uppercase tracking-wide opacity-70">анонсы</span>
        </button>
        {YEARS.map((y) => (
          <button
            key={y}
            type="button"
            onClick={() => { setYear(y); haptic(6); }}
            className={cn("h-11 shrink-0 rounded-[12px] px-4 text-[15px] font-semibold transition-colors", year === y ? "bg-white text-black" : "bg-surface-2 text-on-surface-variant")}
          >
            {y}
          </button>
        ))}
      </div>

      <div className="flex items-center justify-between gap-3 px-4 pb-1 md:px-6">
        <div className="min-w-0">
          <h2 className="text-[22px] font-bold tracking-[-0.02em] text-on-surface">{year}</h2>
          <p className="text-[13px] text-on-surface-variant">
            {tracks.length ? `${tracks.length} треков · OP ${counts.OP} · ED ${counts.ED}` : "собираем данные…"}
          </p>
        </div>
        <button
          type="button"
          onClick={() => { if (tracks.length) { player.playTracks(tracks, 0, { shuffle: true }); player.openNowPlaying(); } }}
          disabled={!tracks.length}
          className="tap-scale flex h-10 shrink-0 items-center gap-1.5 rounded-[11px] bg-surface-2 px-4 text-[14px] font-semibold text-on-surface disabled:opacity-40"
        >
          <Icon name="play_arrow" size={17} />
          Год целиком
        </button>
      </div>

      {r.loading && !tracks.length ? (
        <TrackRowSkeleton count={8} />
      ) : r.error && !tracks.length ? (
        <ErrorState message={r.error} onRetry={r.reload} />
      ) : tracks.length === 0 ? (
        <EmptyState icon="calendar" title="Нет данных за этот год" text="Попробуйте соседний год — каталог пополняется постепенно." />
      ) : (
        <>
          <div className="md:grid md:grid-cols-2 md:gap-x-6">
            {tracks.slice(0, 30).map((t) => (
              <TrackRow key={t.id} track={t} context={tracks} />
            ))}
          </div>
          <div className="flex items-center gap-2 px-4 pt-3 md:px-6">
            <Button variant="tinted" onClick={() => navigate(`/year/${year}`)}>
              Все песни и аниме {year}
            </Button>
          </div>

          {/* Аниме этого года */}
          {(animeR.data?.items.length ?? 0) > 0 && (
            <section className="mt-7">
              <h3 className="mb-2 px-4 text-[17px] font-bold text-on-surface md:px-6">Аниме {year}</h3>
              <HScroll>
                {animeR.data?.items.slice(0, 20).map((a) => (
                  <AnimeCard key={a.id} anime={a} />
                ))}
              </HScroll>
            </section>
          )}
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* НОВИНКИ: календарь по дням                                          */
/* ------------------------------------------------------------------ */
function FreshFeed() {
  const player = usePlayerActions();
  const { period, setPeriod, mature } = useGeneralStore();
  const [tick, setTick] = useState(0);
  const [day, setDay] = useState<string | null>(null);
  const days = useMemo(() => lastDays(7), []);

  const r = useAsync<Track[]>((s) => getFreshTracks(period, 60, { signal: s, refresh: tick > 0, priority: "high" }), [tick, period]);
  const tracks = useMemo(() => filterMature(r.data ?? [], mature), [r.data, mature]);
  const dayCounts = useMemo(() => {
    const m = new Map<string, number>();
    for (const t of tracks) {
      const k = dayKey(t.createdAt);
      if (k) m.set(k, (m.get(k) ?? 0) + 1);
    }
    return m;
  }, [tracks]);
  const shown = useMemo(() => (day ? tracks.filter((t) => dayKey(t.createdAt) === day) : tracks), [tracks, day]);

  useEffect(() => warmMeta(tracks.map((t) => t.anime.malId)), [tracks]);

  return (
    <div className="pt-3">
      <div className="px-4 pb-2 md:px-6">
        <Segmented value={period} onChange={setPeriod} items={[{ value: "today", label: "Сегодня" }, { value: "week", label: "Неделя" }, { value: "all", label: "Всё время" }]} />
      </div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-2 md:px-6">
        <button type="button" onClick={() => { setDay(null); haptic(6); }} className={cn("h-11 shrink-0 rounded-[12px] px-4 text-[14px] font-medium", day === null ? "bg-white text-black" : "bg-surface-2 text-on-surface-variant")}>
          Все · {tracks.length}
        </button>
        {days.map((d) => {
          const count = dayCounts.get(d.key) ?? 0;
          const active = day === d.key;
          return (
            <button
              key={d.key}
              type="button"
              onClick={() => { setDay(active ? null : d.key); haptic(6); }}
              className={cn("flex h-11 w-[68px] shrink-0 flex-col items-center justify-center rounded-[12px]", active ? "bg-white text-black" : count ? "bg-surface-2 text-on-surface" : "bg-surface-1 text-on-surface-dim")}
            >
              <span className="text-[11.5px]">{d.label}</span>
              <span className={cn("text-[12px] font-semibold", active ? "text-black/70" : "text-on-surface-variant")}>{count || "—"}</span>
            </button>
          );
        })}
      </div>
      <div className="flex items-center gap-2 px-4 pb-1 md:px-6">
        <button
          type="button"
          onClick={() => shown.length && player.playTracks(shown, 0, { shuffle: true })}
          disabled={!shown.length}
          className="tap-scale flex h-10 flex-1 items-center justify-center gap-1.5 rounded-[11px] bg-surface-2 text-[15px] font-semibold text-on-surface disabled:opacity-40"
        >
          <Icon name="shuffle" size={18} />
          Слушать {shown.length ? `· ${shown.length}` : ""}
        </button>
        <IconButton icon="refresh" label="Обновить" size={20} className="h-10 w-10 bg-surface-2 text-on-surface" onClick={() => setTick((x) => x + 1)} disabled={r.loading} />
      </div>
      {r.loading && !tracks.length ? (
        <TrackRowSkeleton count={8} />
      ) : r.error && !tracks.length ? (
        <ErrorState message={r.error} onRetry={r.reload} />
      ) : shown.length === 0 ? (
        <EmptyState icon="calendar" title="За этот день пополнений нет" text="Выберите другой день или «Всё время»." />
      ) : (
        <div className="mt-1 md:grid md:grid-cols-2 md:gap-x-6">
          {shown.map((t) => (
            <TrackRow key={t.id} track={t} context={shown} trailing={<span className="shrink-0 text-[11px] text-on-surface-dim">{relativeDay(t.createdAt)}</span>} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* ЖАНРЫ                                                              */
/* ------------------------------------------------------------------ */
function GenresFeed() {
  const player = usePlayerActions();
  const { mature } = useGeneralStore();
  const [genre, setGenre] = useState<string | null>(null);
  const r = useAsync<Track[]>((s) => getRandomTracks(80, undefined, { signal: s, priority: "high" }), []);
  const base = useMemo(() => filterMature(r.data ?? [], mature), [r.data, mature]);
  const filtered = useGenreFilter(base, genre);

  useEffect(() => warmMeta(base.map((t) => t.anime.malId)), [base]);

  const cards: { id: string; label: string }[] = useMemo(() => GENRES.map((g) => ({ id: g.id, label: g.label })), []);

  return (
    <div className="pt-3">
      <div className="grid grid-cols-2 gap-2.5 px-4 pb-2 md:grid-cols-4 md:px-6">
        {cards.map((g) => (
          <button
            key={g.id}
            type="button"
            onClick={() => { setGenre(genre === g.id ? null : g.id); haptic(6); }}
            className={cn("tap-scale flex h-[54px] items-center justify-center rounded-[14px] text-[15px] font-semibold transition-colors", genre === g.id ? "bg-white text-black" : "bg-surface-2 text-on-surface")}
          >
            {g.label}
          </button>
        ))}
      </div>
      <div className="flex items-center gap-2 px-4 pb-1 md:px-6">
        <button
          type="button"
          onClick={() => filtered.length && player.playTracks(filtered, 0, { shuffle: true })}
          disabled={!filtered.length}
          className="tap-scale flex h-10 flex-1 items-center justify-center gap-1.5 rounded-[11px] bg-surface-2 text-[15px] font-semibold text-on-surface disabled:opacity-40"
        >
          <Icon name="shuffle" size={18} />
          {genre ? `${cards.find((c) => c.id === genre)?.label} · ${filtered.length}` : "Все жанры"}
        </button>
        <IconButton icon="refresh" label="Обновить" size={20} className="h-10 w-10 bg-surface-2 text-on-surface" onClick={r.reload} disabled={r.loading} />
      </div>
      {r.loading && !base.length ? (
        <TrackRowSkeleton count={8} />
      ) : filtered.length === 0 ? (
        <EmptyState icon="filter_alt" title="Пусто" text="Выберите другой жанр." />
      ) : (
        <div className="mt-1 md:grid md:grid-cols-2 md:gap-x-6">
          {filtered.map((t) => (
            <TrackRow key={t.id} track={t} context={filtered} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* ЕЩЁ: полные версии сообщества + фрагменты разных записей            */
/* ------------------------------------------------------------------ */
function ExtraFeed() {
  const player = usePlayerActions();
  const { toast } = useUIActions();
  const { settings } = useSettings();
  const [tick, setTick] = useState(0);
  const [busy, setBusy] = useState<string | null>(null);

  const r = useAsync<Track[]>((s) => randomExtras(28, s), [tick], settings.extraSources);
  const list = r.data ?? [];
  const full = useMemo(() => list.filter((t) => !t.preview), [list]);
  const previews = useMemo(() => list.filter((t) => t.preview), [list]);

  const reload = () => setTick((x) => x + 1);

  const runQuery = async (key: string, q: string, fn: (query: string, signal?: AbortSignal) => Promise<Track[]>) => {
    try {
      setBusy(key);
      const res = await fn(q);
      if (!res.length) return toast("Ничего не нашлось");
      player.playTracks(res, 0, { shuffle: true });
      player.openNowPlaying();
    } catch {
      toast("Источник не ответил");
    } finally {
      setBusy(null);
    }
  };

  if (!settings.extraSources) {
    return <EmptyState icon="layers" title="Дополнительные источники выключены" text="Включите «Расширенная база» в настройках." />;
  }

  return (
    <div className="pt-3">
      <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-2 md:px-6">
        {[
          { key: "full", label: "Полные версии", q: "anime opening full" },
          { key: "live", label: "Живые записи", q: "anime song live" },
          { key: "inst", label: "Инструменталы", q: "anime instrumental" },
          { key: "cover", label: "Каверы", q: "anime opening cover" },
          { key: "tv", label: "TV-size", q: "anime tv size" },
        ].map((c) => (
          <Chip
            key={c.key}
            className="h-10"
            onClick={() =>
              runQuery(
                c.key,
                c.q,
                c.key === "full" ? searchCommunity : c.key === "tv" ? searchStudio : searchMix,
              )
            }
          >
            {busy === c.key ? <Spinner size={14} /> : c.label}
          </Chip>
        ))}
      </div>

      <div className="flex items-center gap-2 px-4 pb-1 md:px-6">
        <button
          type="button"
          onClick={() => list.length && player.playTracks(list, 0, { shuffle: true })}
          disabled={!list.length}
          className="tap-scale flex h-10 flex-1 items-center justify-center gap-1.5 rounded-[11px] bg-surface-2 text-[15px] font-semibold text-on-surface disabled:opacity-40"
        >
          <Icon name="shuffle" size={18} />
          Слушать всё · {list.length}
        </button>
        <IconButton icon="refresh" label="Обновить" size={20} className="h-10 w-10 bg-surface-2 text-on-surface" onClick={reload} disabled={r.loading} />
      </div>

      {r.loading && !list.length ? (
        <TrackRowSkeleton count={8} />
      ) : r.error && !list.length ? (
        <ErrorState message="Источники не ответили" onRetry={r.reload} />
      ) : (
        <>
          {full.length > 0 && (
            <section className="mt-2">
              <h3 className="mb-1 px-4 text-[15px] font-bold text-on-surface md:px-6">Полные версии · {full.length}</h3>
              <div className="md:grid md:grid-cols-2 md:gap-x-6">
                {full.map((t) => (
                  <TrackRow key={t.id} track={t} context={list} />
                ))}
              </div>
            </section>
          )}
          {previews.length > 0 && (
            <section className="mt-6">
              <h3 className="mb-1 px-4 text-[15px] font-bold text-on-surface md:px-6">Фрагменты · {previews.length}</h3>
              <HScroll>
                {previews.map((t) => (
                  <TrackCard key={t.id} track={t} context={list} />
                ))}
              </HScroll>
            </section>
          )}
        </>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Страница года: песни + аниме                                        */
/* ------------------------------------------------------------------ */
export function YearPage() {
  const { year: yearStr } = useParams();
  const year = Number(yearStr) || CURRENT_YEAR;
  const [params, setParams] = useSearchParams();
  const season = (params.get("season") as Season | null) ?? null;
  const navigate = useNavigate();
  const player = usePlayerActions();
  const { toast } = useUIActions();
  const { mature } = useGeneralStore();
  const [items, setItems] = useState<AnimeSummary[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [busy, setBusy] = useState(false);

  const first = useAsync((s) => getSeasonAnime(year, season, 1, { signal: s, priority: "high" }), [year, season]);
  const yearTracks = useAsync<Track[]>((s) => getYearTracks(year, 120, { signal: s, priority: "high" }), [year]);
  const trackList = useMemo(() => filterMature(yearTracks.data ?? [], mature), [yearTracks.data, mature]);

  useEffect(() => {
    if (first.data) {
      setItems(first.data.items);
      setHasMore(first.data.hasMore);
      setPage(1);
    }
  }, [first.data]);
  useEffect(() => warmMeta([...items.map((a) => a.malId), ...trackList.map((t) => t.anime.malId)]), [items, trackList]);

  const loadMore = async () => {
    const next = page + 1;
    const r = await getSeasonAnime(year, season, next);
    setItems((prev) => uniqueBy([...prev, ...r.items], (a) => String(a.id)));
    setHasMore(r.hasMore);
    setPage(next);
  };

  const setSeason = (s: Season | null) => {
    const n = new URLSearchParams(params);
    if (s) n.set("season", s);
    else n.delete("season");
    setParams(n, { replace: true });
  };

  const playSeason = async () => {
    if (!season) return;
    try {
      setBusy(true);
      const tracks = await getSeasonTracks(year, season);
      if (!tracks.length) return toast("Нет треков");
      player.playTracks(tracks, 0, { shuffle: true });
      player.openNowPlaying();
    } catch {
      toast("Не удалось загрузить");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="animate-fade-in pb-8">
      <TopBar
        back
        title={String(year)}
        actions={
          <div className="flex items-center">
            <IconButton icon="expand_more" label="Предыдущий" size={20} className="h-9 w-9 rotate-90 text-on-surface" onClick={() => navigate(`/year/${year - 1}${season ? `?season=${season}` : ""}`, { replace: true })} disabled={year <= 1990} />
            <IconButton icon="expand_more" label="Следующий" size={20} className="h-9 w-9 -rotate-90 text-on-surface" onClick={() => navigate(`/year/${year + 1}${season ? `?season=${season}` : ""}`, { replace: true })} disabled={year > CURRENT_YEAR + 1} />
          </div>
        }
      />
      <div className="mx-auto max-w-6xl">
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pt-2 md:px-6">
          <Chip active={!season} onClick={() => setSeason(null)}>
            Весь год
          </Chip>
          {SEASONS.map((s) => (
            <Chip key={s} active={season === s} onClick={() => setSeason(s)}>
              {SEASON_RU[s]}
            </Chip>
          ))}
        </div>

        {season && items.length > 0 && (
          <div className="px-4 pt-3 md:px-6">
            <button type="button" onClick={playSeason} disabled={busy} className="tap-scale flex h-10 w-full items-center justify-center gap-1.5 rounded-[11px] bg-surface-2 text-[15px] font-semibold text-on-surface">
              <Icon name="shuffle" size={18} />
              {busy ? "Загрузка…" : `Слушать ${SEASON_RU[season].toLowerCase()} ${year}`}
            </button>
          </div>
        )}

        {/* Песни года */}
        <section className="mt-3">
          <div className="flex items-center justify-between gap-3 px-4 md:px-6">
            <h2 className="text-[20px] font-bold tracking-[-0.02em] text-on-surface">Песни · {trackList.length}</h2>
            <button
              type="button"
              onClick={() => trackList.length && player.playTracks(trackList, 0, { shuffle: true })}
              disabled={!trackList.length}
              className="tap-scale flex h-9 shrink-0 items-center gap-1.5 rounded-[10px] bg-surface-2 px-3.5 text-[13.5px] font-semibold text-on-surface disabled:opacity-40"
            >
              <Icon name="shuffle" size={16} />
              Слушать
            </button>
          </div>
          {yearTracks.loading && !trackList.length ? (
            <TrackRowSkeleton count={8} />
          ) : (
            <div className="md:grid md:grid-cols-2 md:gap-x-6">
              {trackList.slice(0, 40).map((t) => (
                <TrackRow key={t.id} track={t} context={trackList} />
              ))}
            </div>
          )}
        </section>

        {/* Аниме года */}
        <section className="mt-7">
          <h2 className="mb-2 px-4 text-[20px] font-bold tracking-[-0.02em] text-on-surface md:px-6">Аниме</h2>
          {first.loading && !items.length ? (
            <div className="grid grid-cols-3 gap-3 px-4 sm:grid-cols-4 md:grid-cols-6 md:px-6">
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i}>
                  <Skeleton className="aspect-[2/3] w-full rounded-xl" />
                  <Skeleton className="mt-2 h-3 w-3/4 rounded-md" />
                </div>
              ))}
            </div>
          ) : first.error && !items.length ? (
            <ErrorState message={first.error} onRetry={first.reload} />
          ) : items.length === 0 ? (
            <EmptyState icon="calendar" title="Ничего не найдено" text="Для этого периода пока нет записей." />
          ) : (
            <>
              <div className={cn("grid grid-cols-3 gap-3 px-4 sm:grid-cols-4 md:grid-cols-6 md:px-6")}>
                {items.map((a) => (
                  <AnimeCard key={a.id} anime={a} wide />
                ))}
              </div>
              {hasMore && (
                <div className="flex justify-center pt-6">
                  <Button variant="tinted" onClick={loadMore}>
                    Показать ещё
                  </Button>
                </div>
              )}
            </>
          )}
        </section>
      </div>
    </div>
  );
}
