/**
 * Три дополнительных источника песен (основной каталог НЕ заменяют — только дополняют):
 *  • "studio"    — треки из музыкальных магазинов в виде короткого фрагмента + HD-обложка
 *  • "mix"       — каталог-микс: живые версии, каверы, инструменталы, TV-size
 *  • "community" — загрузки аниме-сообщества: полные версии опенингов/эндингов
 *
 * Все запросы: без ключей, с дисковым кэшем, любая ошибка глушится — UI никогда не падает.
 * Названия источников нигде не показываются: в интерфейсе это «Фрагмент», «Полная версия».
 */
import type { Track } from "@/types";
import { DAY, HOUR, MIN, HOSTS, jsonp, request } from "./http";

const APP = "AniBeat";

/* ------------------------------------------------------------------ */
/* Утилиты                                                             */
/* ------------------------------------------------------------------ */
const norm = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();

function baseTrack(p: {
  id: string;
  title: string;
  artist: string;
  album: string;
  audio: string;
  cover?: string | null;
  coverSmall?: string | null;
  durationMs?: number | null;
  preview?: boolean;
  source: Track["source"];
  slug?: string;
  year?: number | null;
  nsfw?: boolean;
}): Track {
  const numeric = Math.abs([...p.id].reduce((n, c) => (n * 31 + c.charCodeAt(0)) | 0, 7));
  return {
    id: p.id,
    themeId: -numeric,
    themeSlug: p.slug ?? (p.preview ? "PRE" : "FULL"),
    type: "IN",
    sequence: null,
    title: p.title,
    artists: p.artist ? [{ id: -numeric, name: p.artist, slug: "" }] : [],
    anime: { id: -numeric, name: p.album, slug: `ext-${numeric}`, year: p.year ?? null, season: null, malId: null, anilistId: null },
    cover: p.cover ?? null,
    coverSmall: p.coverSmall ?? null,
    audioUrl: p.audio,
    videoUrl: p.audio, // видео нет — режим «Видео» для таких треков недоступен
    resolution: null,
    tags: "",
    version: null,
    episodes: null,
    nsfw: !!p.nsfw,
    spoiler: false,
    source: p.source,
    preview: !!p.preview,
    durationMs: p.durationMs ?? null,
  };
}

function dedupe(list: Track[]): Track[] {
  const seen = new Set<string>();
  const out: Track[] = [];
  for (const t of list) {
    const key = `${norm(t.title)}|${norm(t.artists[0]?.name ?? "")}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(t);
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* 1) Studio-фрагменты (короткие, зато оригинальные записи)            */
/* ------------------------------------------------------------------ */
interface AppleSong {
  trackId: number;
  trackName: string;
  artistName: string;
  collectionName?: string;
  previewUrl?: string;
  artworkUrl100?: string;
  trackTimeMillis?: number;
  releaseDate?: string;
  primaryGenreName?: string;
}

export async function searchStudio(q: string, signal?: AbortSignal): Promise<Track[]> {
  try {
    const url = `${HOSTS.apple}/search?term=${encodeURIComponent(q)}&media=music&entity=song&limit=25`;
    const data = await request<{ results?: AppleSong[] }>(url, { fresh: HOUR, maxAge: 30 * DAY, signal, priority: "low", timeout: 10_000, retries: 1 });
    return (data.results ?? [])
      .filter((r) => r.previewUrl && r.trackName)
      .map((r) =>
        baseTrack({
          id: `studio:${r.trackId}`,
          title: r.trackName,
          artist: r.artistName,
          album: r.collectionName ?? "",
          audio: r.previewUrl as string,
          cover: r.artworkUrl100?.replace("100x100bb.jpg", "900x900bb.jpg") ?? null,
          coverSmall: r.artworkUrl100 ?? null,
          durationMs: r.trackTimeMillis ?? null,
          preview: true,
          source: "studio",
          slug: r.primaryGenreName === "Anime" ? "ANIME" : "PRE",
          year: r.releaseDate ? new Date(r.releaseDate).getFullYear() : null,
        }),
      );
  } catch {
    return [];
  }
}

/* ------------------------------------------------------------------ */
/* 2) Каталог-микс (много вариантов: live, instrumental, TV-size)      */
/* ------------------------------------------------------------------ */
interface DeezerTrack {
  id: number;
  title: string;
  duration?: number;
  preview?: string;
  explicit_lyrics?: boolean;
  artist?: { name?: string };
  album?: { title?: string; cover_xl?: string; cover_big?: string };
}

export async function searchMix(q: string, signal?: AbortSignal): Promise<Track[]> {
  try {
    const url = `${HOSTS.deezer}/search?q=${encodeURIComponent(q)}&limit=25&output=jsonp`;
    const data = await jsonp<{ data?: DeezerTrack[] }>(url, { ttl: 15 * MIN, maxAge: 7 * DAY, signal });
    return (data.data ?? [])
      .filter((r) => r.preview && r.title)
      .map((r) =>
        baseTrack({
          id: `mix:${r.id}`,
          title: r.title,
          artist: r.artist?.name ?? "",
          album: r.album?.title ?? "",
          audio: r.preview as string,
          cover: r.album?.cover_xl ?? null,
          coverSmall: r.album?.cover_big ?? null,
          durationMs: r.duration ? r.duration * 1000 : null,
          preview: true,
          source: "mix",
          nsfw: !!r.explicit_lyrics,
        }),
      );
  } catch {
    return [];
  }
}

/* ------------------------------------------------------------------ */
/* 3) Загрузки сообщества (ПОЛНЫЕ версии)                              */
/* ------------------------------------------------------------------ */
interface AudiusTrack {
  id: string;
  title: string;
  duration?: number;
  description?: string | null;
  permalink?: string;
  is_streamable?: boolean;
  artwork?: Record<string, string>;
  user?: { name?: string };
}

export async function searchCommunity(q: string, signal?: AbortSignal): Promise<Track[]> {
  try {
    const url = `${HOSTS.audius}/v1/tracks/search?query=${encodeURIComponent(q)}&app_name=${APP}&limit=25`;
    const data = await request<{ data?: AudiusTrack[] }>(url, { fresh: HOUR, maxAge: 7 * DAY, signal, priority: "low", timeout: 12_000, retries: 1 });
    return (data.data ?? [])
      .filter((r) => r.id && r.title && r.is_streamable !== false)
      .map((r) => {
        const desc = r.description ?? "";
        const anime = /anime\s*[:\-]\s*([^\n]+)/i.exec(desc)?.[1]?.trim();
        return baseTrack({
          id: `community:${r.id}`,
          title: r.title.replace(/\s*[-–]\s*\[[^\]]*\]\s*$/, "").trim(),
          artist: r.user?.name ?? "Anime community",
          album: anime && anime.length < 60 ? anime : (r.user?.name ?? ""),
          audio: `${HOSTS.audius}/v1/tracks/${r.id}/stream?app_name=${APP}`,
          cover: r.artwork?.["1000x1000"] ?? r.artwork?.["480x480"] ?? null,
          coverSmall: r.artwork?.["480x480"] ?? r.artwork?.["150x150"] ?? null,
          durationMs: r.duration ? r.duration * 1000 : null,
          preview: false,
          source: "community",
        });
      });
  } catch {
    return [];
  }
}

/* ------------------------------------------------------------------ */
/* Объединённые операции                                               */
/* ------------------------------------------------------------------ */
export async function searchExtras(q: string, signal?: AbortSignal): Promise<Track[]> {
  if (q.trim().length < 2) return [];
  const [studio, mix, community] = await Promise.all([searchStudio(q, signal), searchMix(q, signal), searchCommunity(q, signal)]);
  return dedupe([...community, ...studio, ...mix]);
}

/** Случайные запросы: известные песни и названия аниме. */
export const EXTRA_QUERIES = [
  "gurenge lisa", "unravel tokyo ghoul", "idol yoasobi oshi no ko", "kaikai kitan eve", "blue bird naruto",
  "cruel angel's thesis", "silhouette naruto", "departure hunter x hunter", "again yui fullmetal", "tank cowboy bebop",
  "renai circulation", "guren no yumiya", "homura lisa", "zankyou sanka aimer", "kizuna no kiseki",
  "demon slayer opening", "jujutsu kaisen ending", "attack on titan theme", "chainsaw man opening", "dandadan opening",
  "one piece opening", "my hero academia opening", "spy x family ending", "frieren opening", "bocchi the rock",
];

export async function randomExtras(count = 21, signal?: AbortSignal): Promise<Track[]> {
  const picks = [...EXTRA_QUERIES].sort(() => Math.random() - 0.5).slice(0, 3);
  const [community, studio, mix] = await Promise.all([searchCommunity(picks[0], signal), searchStudio(picks[1], signal), searchMix(picks[2], signal)]);
  const pool = dedupe([...community, ...studio, ...mix]);
  return pool.sort(() => Math.random() - 0.5).slice(0, count);
}

/** Дополнение для страницы аниме: ищем по названию аниме и по исполнителю. */
export async function extrasForAnime(names: string[], signal?: AbortSignal): Promise<Track[]> {
  const queries = [...new Set(names.filter((n) => n && n.length > 2))].slice(0, 2);
  if (!queries.length) return [];
  const results = await Promise.all([
    searchCommunity(queries[0], signal),
    searchStudio(queries[0] + (queries[1] ? ` ${queries[1]}` : ""), signal),
    searchMix(queries[0], signal),
  ]);
  return dedupe(results.flat()).slice(0, 40);
}
